// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

/* The name of this package (not localized) */
const PACKAGE_NAME = 'cinnamon';
/* The version of this package */
const PACKAGE_VERSION = '2.8.6';
/* The version of GJS we're linking to */
const GJS_VERSION = '2.8.0';
/* 1 if gnome-bluetooth is available, 0 otherwise */
const HAVE_BLUETOOTH = 1;
/* The system TLS CA list */
const CINNAMON_SYSTEM_CA_FILE = '/etc/ssl/certs/ca-certificates.crt';
