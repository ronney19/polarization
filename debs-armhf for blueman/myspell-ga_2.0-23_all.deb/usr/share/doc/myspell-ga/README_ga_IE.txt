ispell-gaeilge, aspell-gaeilge, myspell-gaeilge -- 
Irish language spellchecking packages (ISO-639-1 code = "ga")
Copyright 2000, 2001, 2002 Kevin P. Scannell

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


Consult the web page

   http://borel.slu.edu/~kps/ispell/index.html

for detailed information about these packages and installation information.
